const chatMessages = document.getElementById('chatMessages');
const userInput = document.getElementById('userInput');
const sendBtn = document.getElementById('sendBtn');

const API_URL = 'http://127.0.0.1:5000/api/recommend';

function addMessage(content, sender) {
    const messageDiv = document.createElement('div');
    messageDiv.classList.add('message');
    messageDiv.classList.add(sender === 'user' ? 'user-message' : 'ai-message');

    const bubble = document.createElement('div');
    bubble.classList.add('message-bubble');
    bubble.innerHTML = content;
    messageDiv.appendChild(bubble);

    chatMessages.appendChild(messageDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

function showTypingIndicator() {
    const indicator = document.createElement('div');
    indicator.classList.add('message', 'ai-message');
    indicator.id = 'typingIndicator';
    indicator.innerHTML = '<div class="message-bubble">🤔 思考中...</div>';
    chatMessages.appendChild(indicator);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

function removeTypingIndicator() {
    const indicator = document.getElementById('typingIndicator');
    if (indicator) indicator.remove();
}

function formatRecommendations(recommendations) {
    if (!recommendations || recommendations.length === 0) {
        return '抱歉，暂时没有找到符合你要求的菜品。试试调整一下口味、预算或时间吧~';
    }

    let result = '为你推荐以下菜品：\n\n';
    recommendations.forEach((item, index) => {
        result += `${index + 1}. ${item.sname}\n`;
        result += `   💰 价格：${item.sprice}元\n`;
        result += `   ⏱️ 准备时间：${item.stime}分钟\n`;
        result += `   🌶️ 口味：${item.staste}\n\n`;
    });
    return result.replace(/\n/g, '<br>');
}

async function sendMessage() {
    const userText = userInput.value.trim();
    if (!userText) {
        alert('请输入你的用餐需求');
        return;
    }

    addMessage(escapeHtml(userText), 'user');
    userInput.value = '';
    userInput.focus();

    showTypingIndicator();

    try {
        const response = await fetch(API_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ query: userText })
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();
        removeTypingIndicator();

        const aiReply = formatRecommendations(data.recommendations);
        addMessage(aiReply, 'ai');
    } catch (error) {
        console.error('请求后端失败：', error);
        removeTypingIndicator();
        addMessage('抱歉，网络出了点问题，请稍后再试。', 'ai');
    }
}

function escapeHtml(str) {
    return str.replace(/[&<>]/g, function(m) {
        if (m === '&') return '&amp;';
        if (m === '<') return '&lt;';
        if (m === '>') return '&gt;';
        return m;
    });
}

sendBtn.addEventListener('click', sendMessage);
userInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') sendMessage();
});

window.addEventListener('load', () => {
    userInput.focus();
});