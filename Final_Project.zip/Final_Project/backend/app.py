from flask import Flask, request, jsonify
from flask_cors import CORS
from db import insert_user_query, query_dishes
from minimax_client import extract_params_with_minimax
import logging

app = Flask(__name__)
app.config['JSON_AS_ASCII'] = False
CORS(app)

@app.route('/api/recommend', methods=['POST'])
def recommend():
    data = request.get_json()
    if not data or 'query' not in data:
        return jsonify({"error": "缺少 query 字段"}), 400

    user_query = data['query'].strip()
    if not user_query:
        return jsonify({"error": "query 不能为空"}), 400

    # 1. 调用 AI 提取参数
    try:
        params = extract_params_with_minimax(user_query)
    except Exception as e:
        app.logger.error(f"AI 提取失败: {e}")
        params = {"taste": None, "budget": None, "time": None, "people": None}

    taste = params.get('taste')
    budget = params.get('budget')
    time_limit = params.get('time')
    people = params.get('people')

    # 2. 存储用户查询记录
    try:
        insert_user_query(taste, budget, time_limit, people)
    except Exception as e:
        app.logger.error(f"插入历史记录失败: {e}")

    # 3. 从 dish 表中查询符合要求的菜品
    try:
        dishes = query_dishes(taste, budget, time_limit)
    except Exception as e:
        app.logger.error(f"数据库查询失败: {e}")
        return jsonify({"error": "数据库查询失败"}), 500

    # 4. 返回结果（前端期望 recommendations 数组）
    return jsonify({"recommendations": dishes})

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)