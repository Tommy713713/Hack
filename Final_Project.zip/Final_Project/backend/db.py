import pymysql
import os
import uuid
from dotenv import load_dotenv

load_dotenv()

def get_db_connection():
    """获取 MySQL 数据库连接"""
    return pymysql.connect(
        host=os.getenv('DB_HOST', 'localhost'),
        user=os.getenv('DB_USER', 'root'),
        password=os.getenv('DB_PASSWORD', ''),
        database=os.getenv('DB_NAME', 'ai_canteen'),
        charset='utf8mb4',
        cursorclass=pymysql.cursors.DictCursor
    )

def insert_user_query(taste, budget, time_limit, people):
    """
    将提取的参数存入 ai_canteen_assistant 表
    sno 使用 UUID 前20位作为主键
    """
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            # 生成主键：UUID 前20位（去掉横线）
            sno = uuid.uuid4().hex[:20]
            sql = """
                INSERT INTO ai_canteen_assistant 
                (sno, staste, sbudget, stime, speople) 
                VALUES (%s, %s, %s, %s, %s)
            """
            # 将数字转为字符串存储（表字段为 varchar）
            budget_str = str(budget) if budget is not None else None
            time_str = str(time_limit) if time_limit is not None else None
            people_str = str(people) if people is not None else None
            cursor.execute(sql, (sno, taste, budget_str, time_str, people_str))
        conn.commit()
    finally:
        conn.close()

def query_dishes(taste=None, budget=None, time_limit=None):
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            sql = "SELECT * FROM dish WHERE 1=1"
            params = []

            if taste:
                sql += " AND staste LIKE %s"
                params.append(f'%{taste}%')
            if budget is not None:
                sql += " AND CAST(sprice AS DECIMAL(10,2)) <= %s"
                params.append(budget)
            if time_limit is not None:
                sql += " AND CAST(stime AS SIGNED) <= %s"
                params.append(time_limit)

            sql += " ORDER BY sid LIMIT 5"
            print("SQL:", sql)          # 调试输出
            print("Params:", params)    # 调试输出
            cursor.execute(sql, params)
            result = cursor.fetchall()
            print("Found rows:", len(result))  # 调试输出
        return result
    finally:
        conn.close()