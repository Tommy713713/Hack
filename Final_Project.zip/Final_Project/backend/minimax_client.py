import os
import re
import json
import requests
from dotenv import load_dotenv

load_dotenv()

USE_MOCK = os.getenv('USE_MOCK', 'True').lower() == 'true'

def extract_params_with_minimax(query):
    if USE_MOCK:
        return _mock_extract(query)
    else:
        return _real_minimax_extract(query)

def _mock_extract(query):
    taste = None
    budget = None
    time_limit = None
    people = None

    # 口味关键词
    taste_keywords = {
        '辣': '辣', '清淡': '清淡', '川菜': '川菜', '粤菜': '粤菜'
    }
    for kw, val in taste_keywords.items():
        if kw in query:
            taste = val
            break

    # 预算：数字 + 元/块
    budget_match = re.search(r'(\d+)\s*[元块]', query)
    if budget_match:
        budget = int(budget_match.group(1))

    # 时间：数字 + 分钟
    time_match = re.search(r'(\d+)\s*分钟', query)
    if time_match:
        time_limit = int(time_match.group(1))

    # 人数：数字 + 人/位
    people_match = re.search(r'(\d+)\s*[人位]', query)
    if people_match:
        people = int(people_match.group(1))
    if people is None:
        if '一个人' in query or '1人' in query:
            people = 1
        elif '两个人' in query or '2人' in query:
            people = 2

    return {
        "taste": taste,
        "budget": budget,
        "time": time_limit,
        "people": people
    }

def _real_minimax_extract(query):
    api_key = os.getenv('MINIMAX_API_KEY')
    group_id = os.getenv('MINIMAX_GROUP_ID', '')
    if not api_key:
        raise ValueError("未设置 MINIMAX_API_KEY 环境变量")

    url = f"https://api.minimax.chat/v1/text/chatcompletion_pro?GroupId={group_id}"

    prompt = f"""
请从以下用户输入中提取用餐偏好，返回 JSON 格式，包含字段：
- taste（口味，如辣、清淡、川菜等）
- budget（预算，整数，单位元）
- time（可接受等待时间，整数，单位分钟）
- people（用餐人数，整数）
如果某个字段未提及，则设为 null。

用户输入：{query}

返回格式（仅 JSON，不要其他文字）：
{{"taste": "...", "budget": 数字或null, "time": 数字或null, "people": 数字或null}}
"""
    headers = {
        'Authorization': f'Bearer {api_key}',
        'Content-Type': 'application/json'
    }
    payload = {
        "model": "abab5.5-chat",
        "messages": [{"role": "user", "content": prompt}],
        "temperature": 0.1
    }

    response = requests.post(url, headers=headers, json=payload, timeout=10)
    if response.status_code != 200:
        raise Exception(f"MiniMax API 调用失败: {response.text}")

    data = response.json()
    reply = data['choices'][0]['message']['content']
    if reply.startswith('```json'):
        reply = reply[7:]
    if reply.endswith('```'):
        reply = reply[:-3]
    result = json.loads(reply.strip())

    return {
        "taste": result.get('taste'),
        "budget": result.get('budget'),
        "time": result.get('time'),
        "people": result.get('people')
    }